"""
This module contains unit tests for the pdf_utils module. You only need
this if you are contributing to this module's code, but it might be
useful as example code. 
"""
from .test_config import test_config
