# PDF Utils
PDF Utilities to make common tasks a bit easier. Currently, it just contains
fixes I need for the documents produced by my one-sided scanner, but I may add
to it as time permits.  

There is only one class: `pdf_utils.PDF`. You can read all about it at the 
[GitHub Pages documentation](https://gismaps.github.io/PDF_Utils)
or by checking code out of GitHub and navigating to the `docs` folder. 

